---
tags: [第9讲, CFFM, 跨域融合, 注意力, 空间注意力]
aliases: [第9讲, CFFM 精讲, 跨域特征融合模块]
created: 2026-11-03
related: "[[00-索引 MOC]]", "[[12-第7讲-CCDD结构精讲]]", "[[13-第8讲-PixelShuffle与上采样vs采样]]", "[[05-第4讲-多任务损失与梯度冲突]]", "[[07-第6讲-批判性评价与可做选题]]"
---

# 第 9 讲：CFFM 跨域特征融合（Cross-domain Feature Fusion Module）

> [!important] 本讲定位
> CFFM 是整篇论文里"**跨域**"二字的落点，也是三模块中**最轻巧**的一个 —— 只有 **99 个参数**。
> 搞清楚它，你就理解了"融合"和"拼接"的本质区别。

> [!note] 论文出处
> ISPRS J. P&RS 236 (2026) 552–568 · **Section 3.3** · Eq. (4)–(7) · **Fig. 2(A)**

![[附件/fig2_framework.png]]

> 上图 **左上角 (A) 部分**（紫框区域）就是 CFFM。

---

## 9.1 一句话总结

> **CFFM 给每个像素点单独拉一根"推子"：推上去就多信雾域特征 S2，拉下来就多信去雾特征 F_clean。**

---

## 9.2 它要解决什么问题？

先看清 `S2` 和 `F_clean` 这两份"底片"**各自的优点和缺点**：

| | 优点 | 缺点 |
|---|---|---|
| **S2**（雾域，冻结编码器原始输出） | 几何结构**准**（没有重建误差） | 雾蒙蒙，纹理糊、对比度低 |
| **F_clean**（净域，DFEM 增强后） | 清晰、纹理丰富 | 可能带**重建伪影**、丢判别信息 |

论文原话：

> *"hazy image features often suffer from texture blurring and detail loss; on the other hand, dehazed outputs may introduce artifacts or lose discriminative information if reconstruction is suboptimal."*

**关键在于：这两种缺陷在空间上不是均匀分布的。**

- 某块区域雾重 → 该区域更该信 `F_clean`
- 某块区域是清晰的近处目标 → `F_clean` 可能重建失真，更该信 `S2`
- 某块区域是强边缘结构 → `S2` 的结构信息更可靠

所以**不该一刀切**，必须**逐像素自适应**。

> 🎯 **比喻：两张底片做交叉淡化（crossfade）**
> - 底片 A = 原始雾拍，结构准但发灰
> - 底片 B = 去雾重拍，干净但可能拍糊了
> - 剪辑师逐帧决定"这块用 A、那块用 B、接缝处做淡入淡出"
>
> **CFFM 就是那个剪辑师**，而且它是**自动剪辑**（学出来的）。

---

## 9.3 五步走完（带形状）

```
S2      (256, 200, 334)   ← 雾域
F_clean (256, 200, 334)   ← 净域
   │
   │ ① 通道维 Concat
   ▼
F_u     (512, 200, 334)
   │
   │ ② 沿【通道维】分别做 avg pool 和 max pool
   ▼
S_avg   (1, 200, 334)     ← 每格 256 个值的平均
S_max   (1, 200, 334)     ← 每格 256 个值的最大
   │
   │ ③ Concat 后过一个 7×7 卷积 + Sigmoid
   ▼
F_att   (1, 200, 334)     ← 【推子位置图】，每格 0~1
   │
   │ ④ 互补门控
   ▼
F_fu = (S2 ⊙ F_att) + (F_clean ⊙ (1 - F_att))
   │
   ▼
F_fu    (256, 200, 334)   ← 送进 backbone layer3-5
```

### 对应公式

$$
F_u = \text{Concat}(S2, F_{clean}) \tag{4}
$$

$$
S_{avg} = p_{avg}(F_u), \qquad S_{max} = p_{max}(F_u) \tag{5}
$$

$$
F_{att} = \sigma\Bigl(f_{conv}\bigl(\text{Concat}(S_{avg}, S_{max})\bigr)\Bigr) \tag{6}
$$

$$
F_{fu} = (S2 \odot F_{att}) + \bigl(F_{clean} \odot (1 - F_{att})\bigr) \tag{7}
$$

其中 `p_avg` / `p_max` 是**通道维**的池化，`f_conv` 是 **7×7 卷积，padding 3**，`σ` 是 Sigmoid，`⊙` 是逐元素乘。

---

## 9.4 三个设计细节（考试 / 审稿会问的）

### ① 为什么池化是**沿通道维**做的？

这一步最容易被误解。池化沿**通道**维（对 512 个通道取平均/最大），**空间尺寸 H×W 完全保留**。

所以输出是 `(1, H, W)` 而不是 `(C, 1, 1)`。

> [!tip] 这是"空间注意力"而不是"通道注意力"
> - 通道注意力（SE）→ 输出 `(C, 1, 1)`，回答"**哪种特征重要**"
> - 空间注意力（CFFM / CBAM）→ 输出 `(1, H, W)`，回答"**哪个位置重要**"
>
> CFFM 要回答的是"这个像素该信谁"，是**位置**问题 → 必须保留空间尺寸。

### ② 为什么 max 和 avg 都要？

| | 擅长 | 怕什么 |
|---|---|---|
| **avg** | 反映一片区域的**整体响应强度** | 噪声被平均掉，弱边缘被稀释 |
| **max** | 抓住**最显著的**边缘/纹理在哪 | 被单个异常值（脉冲噪声）带偏 |

两者互补：avg 说"这块整体雾重"，max 说"这块有个强边缘"。

### ③ 为什么是 7×7？

因为**这是区域级决策**，不是像素级。要判断"这一大片该信谁"，看得见 3×3（太小，只看局部噪声）或 11×11（太大，参数多）。

在 1/4 分辨率上，7×7 覆盖原图的 **28×28 像素** —— 差不多是一个小车的尺度。

---

## 9.5 参数量账：99 个参数

`f_conv` 是 `Conv2d(2, 1, 7, padding=3)`：

$$
7\times7\times2\times1 + 1 = \mathbf{99}
$$

**整个 CFFM 只有 99 个参数**，占全模型 36.61M 的 **0.00027%**。

| 模块 | 参数量 | 占比 |
|---|---|---|
| DFEM (CCDD) | 3,540,480 | 9.7% |
| MFAM ×3 | 4,979,712 | 13.6% |
| **CFFM** | **99** | **0.0003%** |

> 🎯 **比喻**：一个装了整面墙的智能家居系统（几百万参数），里面藏了一颗**手动调音台的推子**（99 个参数）—— 真正决定混音效果的，就是它。

---

## 9.6 梯度视角：推子位置是**学出来的**，不是人定的

这是 CFFM 最容易被忽略的一层：

```
F_att ← 依赖 S2 和 F_clean
F_clean ← DFEM(S2)
```

所以：

- `F_att` 的梯度会**穿过 F_clean 回传到 DFEM** → 去雾模块会被"推子"反向影响
- `F_att` 又影响 `F_fuse` → 影响检测 → **检测损失 L_od 也在教 CFFM 怎么放推子**

$$
\text{谁该信} \;=\; \text{去雾目标} + \text{检测目标} \;\text{共同学出来的}
$$

> [!important] 这才是论文标题里 "**collaborative**（协同）"的完整含义
> 不只是"去雾帮检测"，而是"**检测也在帮去雾决定哪里该信**"。

---

## 9.7 实现参考（已实测跑通）

```python
class CFFM(nn.Module):
    """论文 Eq.4 - Eq.7"""
    def __init__(self, channels: int = 256):
        super().__init__()
        self.gate = nn.Conv2d(2, 1, 7, padding=3)   # 99 参数

    @staticmethod
    def _channel_pool(x):
        # x: (C,H,W) -> avg/max over channel dim -> (1,H,W)
        return x.mean(dim=1, keepdim=True), x.max(dim=1, keepdim=True)[0]

    def forward(self, s2, f_clean):
        assert s2.shape == f_clean.shape
        f_u   = torch.cat([s2, f_clean], dim=1)                    # (512,H,W)
        s_avg, s_max = self._channel_pool(f_u)                     # (1,H,W) ×2
        f_att = torch.sigmoid(self.gate(torch.cat([s_avg, s_max], dim=1)))
        return s2 * f_att + f_clean * (1 - f_att)                  # (256,H,W)
```

完整练习包见 `work/practice/ccfa_modules.py`。

---

## 9.8 ⚠️ 批判性：论文没说的三件事

### (1) CFFM ≈ CBAM 的 spatial attention，改动很小

CBAM（Woo et al., ECCV 2018）的空间注意力分支：

$$
F_{att}^{CBAM} = \sigma\bigl(f_{7\times7}([\,\text{AvgPool}(x),\ \text{MaxPool}(x)\,])\bigr)
$$

CFFM 的 Eq.6 **几乎一字不差**，只改了两处：

- 输入从"同一个 x" 换成 "**两个域的 Concat**"
- 最后的融合从 "乘 x" 换成 "**互补凸组合**"

**论文完全没提 CBAM 这个来源。** 审稿人如果知道这层关系，会问 "novelty 在哪"。

### (2) 提升幅度在噪声量级

论文 Table 10：

| 融合方式 | mAP |
|---|---|
| Concat | 54.1 |
| AFF | 54.2 |
| CGFU | 54.3 |
| **CFFM** | **54.6** |

**只比 Concat 高 0.3。** 而论文**全文没有报告任何方差 / 多种子结果** → 0.3 完全在随机波动范围内。

### (3) CFFM 的独立贡献**从未被验证**

Table 8 的 8 行只做了 6 行，缺的正是：

- ❌「**只加 CFFM**」（不加 CCDD）
- ❌「**CFFM + MFAM**」（不加 CCDD）

旁证来自 Table 13：**λ = 0（完全拿掉去雾监督）时 mAP = 52.8**，而 Table 8 里「CCDD + CFFM」= **52.9**。

> **几乎相等** → 说明没有 CCDD 提供干净内容时，CFFM 单独干活基本没用。
> **CFFM 是 CCDD 的配套件，不是独立贡献。**

---

## 9.9 自测题

1. `F_att` 的形状是 `(1, H, W)`，如果改成 `(C, 1, 1)` 会变成什么模块？（提示：想想 SE）
2. 公式 (7) 里两个权重是 `F_att` 和 `1 - F_att`，它们的和恒等于多少？如果改成两边都用 `F_att`（CBAM 式）会出什么问题？
3. `S2` 和 `F_clean` 都是 256 通道，为什么要先 Concat 成 512 再池化，不能各自池化后直接 Concat 吗？
4. Table 13 的 λ=0 得 52.8，Table 8 的「CCDD+CFFM」得 52.9 —— 这两个数字几乎相同，说明了什么？
5. 为什么 CFFM 用「互补门控」而不是直接 `F_fu = F_clean ⊙ F_att`？在什么情况下直接乘会出事？

<details>
<summary>👉 自测答案</summary>

**1.** 变成**通道注意力**（SE 式）。但那就回答不了"这个像素该信谁"，而是"哪些特征类型重要"—— 空间信息全丢了，跨域融合的意义消失。

**2.** 恒等于 **1**。这是**凸组合**：输出永远是两份特征的加权平均，永远在两者之间，不会冒出第三种信息。
若两边都用 `F_att`：当 `F_att → 0` 时输出趋近全 0，那一块特征被**整个抹掉**，后面的 backbone 层拿不到任何信号。互补形式保证**至少有一路始终有贡献**。

**3.** 因为融合的决策需要**同时看到两个域**。若各自池化再 Concat，得到的是两张各 256 通道压成的 1 通道图 —— 等于把两个域**先各自压扁**再比较，压扁过程丢信息；而先 Concat 再池化，是**在完整信息下**做联合统计。

**4.** 说明 **CFFM 离开 CCDD 就几乎没有独立价值** —— 它自己没有"干净内容"可提供，只是 CCDD 的配套融合器。这也解释了为什么 Table 8 敢不单独报 CFFM 那行（报了会很难看）。

**5.** 见第 2 问的展开。另外注意：互补形式还保证输出**始终保持 256 通道**（论文原话 *"the output F_fu naturally maintains the 256-channel dimensionality"*），后续 backbone layer3 的输入维度完全不用改。

</details>

---

## 🔗 相关笔记

- [[15-补充-池化基础]] — 第 9.4 节 ① 的前置知识（通道维池化）
- [[16-补充-卷积基础]] — 第 9.4 节 ③ 的前置知识（7×7 卷积的感受野）
- [[12-第7讲-CCDD结构精讲]] — CFFM 的上游（F_clean 从哪来）
- [[13-第8讲-PixelShuffle与上采样vs采样]] — CCDD 重建头的核心操作
- [[05-第4讲-多任务损失与梯度冲突]] — L_od 与 L_dh 怎么协作
- [[07-第6讲-批判性评价与可做选题]] — 把 CFFM 的疑点变成可做的实验
- [[08-附录-公式速查手册]] — Eq.4–7 速查
- [[18-第10讲-MFAM多尺度前景感知]] — CBAM 式注意力 vs 本文 CA 式坐标注意力的对照
- [[20-补充-空间注意力图的逻辑依据与意义]] — CFFM 的凸组合门控为什么成立
